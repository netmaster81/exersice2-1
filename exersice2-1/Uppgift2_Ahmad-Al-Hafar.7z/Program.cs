﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exersice2_1
{
    class Program
    {
        static void Main(string[] args)
        {

            //CinemaTicket CC= new CinemaTicket();
            //CC.Main();
            //RepeatTen CC = new RepeatTen(); ;
            //CC.main();
            //ThirdWord CC = new ThirdWord();
            //CC.Main();
            Mainmenu MM = new Mainmenu();
            MM.TaskPrintMenu();
            MM.Menu();
            //Console.ReadLine();
            //Console.ReadLine();
            //Console.ReadLine();
            //Console.ReadLine();
        }
    }
}
